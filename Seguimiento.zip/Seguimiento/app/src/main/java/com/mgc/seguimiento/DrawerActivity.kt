package com.mgc.seguimiento

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView

class DrawerActivity : AppCompatActivity() {
    private val TIMER_RUNTIME = 3000
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_drawer)

        val navView = findViewById<NavigationView>(R.id.nav_view)


        val progressBar = findViewById<ProgressBar>(R.id.progressBar)

        Thread {
            var tiempo = 0
            while (tiempo < TIMER_RUNTIME) {
                Thread.sleep(200)
                tiempo += 200

                runOnUiThread {
                    progressBar.progress = tiempo * 100 / TIMER_RUNTIME
                }
            }

            runOnUiThread {
                Toast.makeText(this, "Carga completa", Toast.LENGTH_SHORT).show()
            }

        }.start()

        navView.setNavigationItemSelectedListener { item: MenuItem ->
            when (item.itemId) {

                R.id.nav_inicio -> {
                    Toast.makeText(this, "Inicio", Toast.LENGTH_SHORT).show()
                }

                R.id.nav_moneda -> {
                    startActivity(Intent(this, MonedaActivity::class.java))
                }

                R.id.nav_segunda -> {
                    startActivity(Intent(this, SegundaActividad::class.java))
                }
            }
            true
        }
    }
}