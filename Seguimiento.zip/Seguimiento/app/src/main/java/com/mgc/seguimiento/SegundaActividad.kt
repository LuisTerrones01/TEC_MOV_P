package com.mgc.seguimiento

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.util.Log
import android.widget.ProgressBar
import android.widget.Toast
import com.mgc.seguimiento.databinding.ActivityMainBinding

class SegundaActividad : AppCompatActivity() {

    private val TIMER_RUNTIME = 10000
    private var nbActivo = false
    private lateinit var nProgressBar: ProgressBar

    private lateinit var binding: ActivityMainBinding
    private val TAG = "Ciclo de Vida 2"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        Log.d(TAG, "En el evento onCreate()2")

        setContentView(R.layout.activity_segunda_actividad)

        nProgressBar = findViewById(R.id.progressBar)

        val timerThread = Thread {
            nbActivo = true
            try {
                var espera1 = 0
                while (nbActivo && espera1 < TIMER_RUNTIME) {
                    Thread.sleep(200)
                    if (nbActivo) {
                        espera1 += 200
                        actualizarProgress(espera1)
                    }
                }
            } catch (e: InterruptedException) {
                e.printStackTrace()
            } finally {
                onContinuar()
            }
        }

        timerThread.start()
    }

    private fun actualizarProgress(timePassed: Int) {
        runOnUiThread {
            val progress = nProgressBar.max * timePassed / TIMER_RUNTIME
            nProgressBar.progress = progress
        }
    }

    private fun onContinuar() {
        runOnUiThread {
            Toast.makeText(this, "Carga completa", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onStart()   { super.onStart();   Log.d(TAG, "En el evento onStart() 2") }
    override fun onRestart(){ super.onRestart(); Log.d(TAG, "En el evento onRestart() 2") }
    override fun onResume() { super.onResume();  Log.d(TAG, "En el evento onResume() 2" ) }
    override fun onPause()  { super.onPause();   Log.d(TAG, "En el evento onPause() 2" ) }
    override fun onStop()   { super.onStop();    Log.d(TAG, "En el evento onStop() 2") }
    override fun onDestroy(){ super.onDestroy(); Log.d(TAG, "En el evento onDestroy() 2") }
}

