package com.mgc.seguimiento

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MonedaActivity : AppCompatActivity() {

    private lateinit var editTextCantidad: EditText
    private lateinit var spinnerOrigen: Spinner
    private lateinit var spinnerDestino: Spinner
    private lateinit var progressBar: ProgressBar
    private val TIMER_RUNTIME = 3000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_moneda)

        editTextCantidad = findViewById(R.id.editTextText)
        spinnerOrigen = findViewById(R.id.spinnerOrigen)
        spinnerDestino = findViewById(R.id.spinnerDestino)
        progressBar = findViewById(R.id.progressBar)
        iniciarCarga()
        val adapter = ArrayAdapter.createFromResource(
            this,
            R.array.monedas,
            android.R.layout.simple_spinner_item
        )

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        spinnerOrigen.adapter = adapter
        spinnerDestino.adapter = adapter

        findViewById<Button>(R.id.btnConvertir).setOnClickListener {
            convertirMoneda()
        }
    }

    private fun convertirMoneda() {
        val texto = editTextCantidad.text.toString().trim()

        if (texto.isEmpty()) {
            mostrar("Ingresa una cantidad")
            return
        }

        val cantidad = texto.toFloatOrNull()
        if (cantidad == null || cantidad <= 0) {
            mostrar("Número inválido")
            return
        }

        val origen = spinnerOrigen.selectedItem.toString()
        val destino = spinnerDestino.selectedItem.toString()

        if (origen == destino) {
            mostrar("Selecciona monedas diferentes")
            return
        }

        val resultado = convertirGeneral(cantidad, origen, destino)

        mostrar("%.2f %s = %.2f %s".format(cantidad, origen, resultado, destino))
    }

    private fun convertirGeneral(cantidad: Float, origen: String, destino: String): Float {
        val tasas = mapOf(
            "Dólar" to 1.0f,
            "Sol" to 3.43f,
            "Euro" to 0.92f,
            "Libra" to 0.78f,
            "Rupia" to 83.0f,
            "Real" to 5.0f,
            "Peso" to 17.0f,
            "Yuan" to 7.2f,
            "Yen" to 150.0f
        )

        val tasaOrigen = tasas[origen]
        val tasaDestino = tasas[destino]

        if (tasaOrigen == null || tasaDestino == null) {
            mostrar("Error en monedas")
            return 0f
        }

        val enDolares = cantidad / tasaOrigen
        return enDolares * tasaDestino
    }

    private fun mostrar(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }
    private fun iniciarCarga() {
        Thread {
            var tiempo = 0
            while (tiempo < TIMER_RUNTIME) {
                Thread.sleep(200)
                tiempo += 200

                runOnUiThread {
                    progressBar.progress = tiempo * 100 / TIMER_RUNTIME
                }
            }

            runOnUiThread {
                Toast.makeText(this, "Carga completa", Toast.LENGTH_SHORT).show()
            }

        }.start()
    }
}