// Reemplazar el contenido de MainActivity.kt con el siguiente código para observar todos los eventos del ciclo de vida mediante Logcat:
package com.mgc.seguimiento

import android.content.Intent
import android.view.View
import android.os.Bundle
import android.util.Log
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.mgc.seguimiento.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val TAG = "Ciclo de Vida"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        Log.d(TAG, "En el evento onCreate()")

        binding.btnMostrar.setOnClickListener {
            val intent = Intent(this, SegundaActividad::class.java)
            startActivity(intent)
        }


        binding.btnMoneda.setOnClickListener {
            startActivity(Intent(this, MonedaActivity::class.java))
        }
        binding.btnNavigator.setOnClickListener {
            startActivity(Intent(this, DrawerActivity::class.java))
        }
    }

    override fun onStart()   { super.onStart();   Log.d(TAG, "En el evento onStart()") }
    override fun onRestart(){ super.onRestart(); Log.d(TAG, "En el evento onRestart()") }
    override fun onResume() { super.onResume();  Log.d(TAG, "En el evento onResume()") }
    override fun onPause()  { super.onPause();   Log.d(TAG, "En el evento onPause()") }
    override fun onStop()   { super.onStop();    Log.d(TAG, "En el evento onStop()") }
    override fun onDestroy(){ super.onDestroy(); Log.d(TAG, "En el evento onDestroy()") }
}

